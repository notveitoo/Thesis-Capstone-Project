<?php
    @include '../config.php';
    session_start();
    
    if(!isset($_SESSION['admin_name'])){
       header('location:../login_form.php');
    }
    ?>
<?php
// Set timezone to Asia/Manila
date_default_timezone_set('Asia/Manila');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form values
    $room_number = $_POST['room_number'];
    $employee_number = $_POST['employee_number'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $date_start = $_POST['date_start'];
    $date_end = $_POST['date_end'];
    $month_start = $_POST['month_start'];
    $month_end = $_POST['month_end'];
    $year_start = $_POST['year_start'];
    $year_end = $_POST['year_end'];
    $week_start = $_POST['week_start'];
    $week_end = $_POST['week_end'];

     // Check if all $_POST values are empty
     if (
        empty($room_number) &&
        empty($employee_number) &&
        empty($start_time) &&
        empty($end_time) &&
        empty($date_start) &&
        empty($date_end) &&
        empty($month_start) &&
        empty($month_end) &&
        empty($year_start) &&
        empty($year_end) &&
        empty($week_start) &&
        empty($week_end)
    ) {
        $message = "No input was provided.";
        echo $message;
        echo '<br><a class="btn btn-secondary" href="reports.php">Go back</a>';
        exit;
    }

    // Check connection
    if ($conn2->connect_error) {
        die("Connection failed: " . $conn2->connect_error);
    }

    // Query the database based on the selected value
    $query = "SELECT * FROM room_1_attendance WHERE ";

    // Add conditions based on the provided input fields
    if (!empty($room_number)) {
        $query .= "room_number = '$room_number' AND ";
    }

    if (!empty($employee_number)) {
        $query .= "employee_number = '$employee_number' AND ";
    }

    if (!empty($start_time) && !empty($end_time)) {
        $query .= "TIME(time_in) BETWEEN '$start_time' AND '$end_time' AND ";
    }

    if (!empty($week_start) && !empty($week_end)) {
        $query .= "WEEK(date) BETWEEN '$week_start' AND '$week_end' AND ";
    }

    if (!empty($date_start) && !empty($date_end)) {
        $query .= "DATE(date) BETWEEN '$date_start' AND '$date_end' AND ";
    }

    if (!empty($month_start) && !empty($month_end)) {
        $query .= "MONTH(date) BETWEEN '$month_start' AND '$month_end' AND ";
    }

    if (!empty($year_start) && !empty($year_end)) {
        $query .= "YEAR(date) BETWEEN '$year_start' AND '$year_end' AND ";
    }

    // Remove the trailing "AND" from the query
    $query = rtrim($query, " AND ");

    $result = $conn2->query($query);

    if ($result->num_rows > 0) {
        // Generate PDF file with timestamp in the filename
        require('fpdf/fpdf.php');

        class PDF extends FPDF
        {
            // Page header
            function Header()
            {
                // Logo on the left side
                $this->Image('fpdf/ucu.png', 10, 10, 20); // Adjust the image path and position as needed

                // Logo on the right side
                $this->Image('fpdf/cea.png', 265, 10, 20); // Adjust the image path and position as needed

                // Set font and size for the header
                $this->SetFont('Arial', 'B', 14);
                // First header
                $this->Cell(0, 10, 'URDANETA CITY UNIVERSITY', 0, 1, 'C');
                // Second header
                $this->Cell(0, 10, 'COLLEGE OF ENGINEERING AND ARCHITECTURE', 0, 1, 'C');
                // Third header
                $this->SetFont('Arial', 'B', 16); // Adjust the font size as needed
                $this->Cell(0, 10, 'ROOM ATTENDANCE MONITORING REPORT', 0, 1, 'C'); // Add the "ATTENDANCE REPORT" header
                $this->Ln(10);
            }

            // Page footer
            function Footer()
            {
                // Set font and size for the footer
                $this->SetFont('Arial', 'I', 10);
                // Footer left side
                $this->Cell(0, 10, 'Prepared by: Engr. Marco Angelo V. Valles', 0, 0, 'L');
                // Footer right side
                $this->SetX(-40);
                $this->Cell(0, 10, 'Date Created: ' . date('Y-m-d'), 0, 0, 'R');
            }

            // Page content
            function Content($header, $data)
            {
                // Set font for table header
                $this->SetFont('Arial', 'B', 12);

                // Calculate and adjust the width of each table header cell
                $cellWidth = (275 / count($header)); // Adjust the total width (275) as needed
                $this->SetFillColor(204, 204, 204); // Set header background color
                $this->SetTextColor(0); // Set header text color

                // Output table header
                foreach ($header as $col) {
                    $this->Cell($cellWidth, 10, $col, 1, 0, 'C', true);
                }
                $this->Ln();

                // Set font for table content
                $this->SetFont('Arial', '', 12);

                // Output table rows
                foreach ($data as $row) {
                    // Output each column with adjusted width
                    $this->Cell($cellWidth, 10, $row['room_number'], 1);
                    $this->Cell($cellWidth, 10, $row['employee_number'], 1);
                    $this->Cell($cellWidth, 10, $row['employee_name'], 1);
                    $this->Cell($cellWidth, 10, $row['date'], 1);
                    $this->Cell($cellWidth, 10, date('h:i A', strtotime($row['time_in'])), 1);
                    $this->Cell($cellWidth, 10, date('h:i A', strtotime($row['time_out'])), 1);
                    $this->Cell($cellWidth, 10, $row['logged_out_by'], 1);
                    $timeIn = strtotime($row['time_in']);
                    $timeOut = strtotime($row['time_out']);
                    $timeDiff = $timeOut - $timeIn; // Time difference in seconds
                    $timeDiffFormatted = gmdate('H:i:s', $timeDiff); // Format the time difference as HH:MM:SS
                    $this->Cell($cellWidth, 10, $timeDiffFormatted, 1); // Output time difference
                    $this->Ln();
                }
            }
        }

        $pdf = new PDF('L'); // Set landscape orientation
        $pdf->AddPage();

        // Set font
        $pdf->SetFont('Arial', 'B', 14);

        // Define table header
        $header = array('Room No.', 'Employee No.', 'Employee Name', 'Date', 'Time In', 'Time Out', 'Logged Out By', 'Time Taken');


        // Fetch data from the database
        $data =$data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        // Output table content
        $pdf->Content($header, $data);

        // Generate the PDF output with timestamp in the filename
        $filename = 'attendance_report_' . date('Y-m-d') . '.pdf';
        $pdf->Output($filename, 'D');

        // Close PDF object and terminate script
        $pdf->Close();
        exit;
    } else {
        $message = "No data were generated.";
        echo $message;
    }

    // Close database connection
    $conn2->close();

    // Redirect to reports.php with the message as a query parameter
    header('Location: reports.php');
}
?>
