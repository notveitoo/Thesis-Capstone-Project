<?php
    @include '../config.php';
    
    session_start();
    
    if(!isset($_SESSION['admin_name'])){
       header('location:../login_form.php');
    }
    
    ?>
<?php
    if (!$conn2) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    // Perform the search query
    $query = "SELECT accessed_by FROM room_1";
    $result = $conn2->query($query);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $accessed_by = $row['accessed_by'];
        }
    }
    
    // Check if the door status needs to be updated
    if (isset($_POST['door_status'])) {
        $door_status = $_POST['door_status'];

        if ($door_status == 0 && $accessed_by == "user") {
            $sql = "UPDATE room_1 SET status=0 WHERE id=1";
            if (mysqli_query($conn2, $sql)) {
                $sql = "UPDATE room_1 SET accessed_by='admin' WHERE id=1";
                $timezone = new DateTimeZone('Asia/Manila');
                $datetime = new DateTime('now', $timezone);
                $current_time = $datetime->format('Y-m-d H:i:s');
                if (mysqli_query($conn2, $sql)) {
                    $sql = "UPDATE room_1_attendance SET logged_out_by='admin', time_out ='$current_time'  WHERE id = (SELECT MAX(id) FROM room_1_attendance)";
                    if (mysqli_query($conn2, $sql)) {
                        $_SESSION['message'] = "Door lock status updated successfully (User)";
                    }
                }
            }
        } elseif ($door_status == 0 && $accessed_by == "admin") {
            // Update the door status in the database
            $sql = "UPDATE room_1 SET status=0 WHERE id=1";
            if (mysqli_query($conn2, $sql)) {
                $sql = "UPDATE room_1 SET accessed_by='admin' WHERE id=1";
                if (mysqli_query($conn2, $sql)) {
                    $_SESSION['message'] = "Door lock status updated successfully (Admin)";
                }
            }
        } else {
            if ($door_status == 1) {
                // Update the door status in the database
                $sql = "UPDATE room_1 SET status=1 WHERE id=1";
                if (mysqli_query($conn2, $sql)) {
                    $sql = "UPDATE room_1 SET accessed_by='admin' WHERE id=1";
                    if (mysqli_query($conn2, $sql)) {
                        $_SESSION['message'] = "Door lock status updated successfully (Closed)";
                    }
                }
            }
        }
    }
    
    // Retrieve the current door status from the database
    $sql = "SELECT status FROM room_1 WHERE id=1";
    $result = mysqli_query($conn2, $sql);
    $row = mysqli_fetch_assoc($result);
    $door_status = $row['status'];
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Administrator Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet"/>
        <link rel="icon" href="../img/cea.png">
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="dashboard.php"><img src="../img/cea.png" style="width: 20%; margin-left:15%; display: inline-block; margin-right: auto; margin-bottom: 0px"></a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="profile.php">Settings</a></li>
                        <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <a class="nav-link" href="dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
							<a class="nav-link" href="employee_details.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-info"></i></i></div>
                                Employee Details
                            </a>
                            <a class="nav-link" href="attendance.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></i></div>
                                Attendance
                            </a>
                            <a class="nav-link" href="reports.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Reports
                            </a>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseManageUsers" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Manage Users
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseManageUsers" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="addUser.php">Add User</a>
                                    <a class="nav-link" href="manageUsers.php">Manage</a>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        <?php if (isset($_SESSION['admin_name'])): ?>
                        <?php echo "Administrator ", ucfirst($_SESSION['admin_name']);  ?> <?php endif ?>
                    </div>
                </nav>
            </div>
            <?php 
                $result = $conn2->query("SELECT employee_number, employee_name, date, time_in, logged_in_pic FROM room_1_attendance ORDER BY id DESC LIMIT 1") or die($db->error);
                $result1 = $conn2->query("SELECT status,accessed_by FROM room_1") or die($db->error);
                ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid" style="width: 35%; text-align: center; font-size:15px">
                        <?php 
                            if (isset($_SESSION['message'])): ?>
                        <div class="d-flex justify-content-around">
                            <div class="alert alert-success alert-dismissible fade show fade-in">
                                <?php echo $_SESSION['message'];
                                    unset($_SESSION['message']);
                                    ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                        <?php endif ?> 
                        <?php
                            while ($row = $result1->fetch_assoc()): 
                                $status = $row['status'];
								$accessed_by = $row['accessed_by'];
                            ?>
                        <?php endwhile; ?>
                        <h2 class="mt-4 mb-4">Room #1 Details</h2>
                        <h4 class="mt-4 mb-4">Occupied By</h4>
                        <table class="table" style="table-layout: fixed; width: 100%">
                            <tbody>
                                <?php
                                    while ($row = $result->fetch_assoc()): 
                                    ?>
                                <tr>
                                    <td width="50%" style="text-align: left;"><label><b>Employee Number<b></label></td>
                                    <td width="50%" style="text-align: right;"><?php if($status == 1){if($accessed_by == 'user'){
									echo $row['employee_number'];}
                                        } else{
                                        echo "";
                                        }
                                        ?></td>
                                </tr>
                                <tr>
                                    <td width="50%" style="text-align: left;"><label><b>Employee Name<b></label></td>
                                    <td width="50%" style="text-align: right;"><?php if($status == 1){if($accessed_by == 'user'){
									echo $row['employee_name'];}
                                        } else{
                                        echo "";
                                        }
                                        ?></td>
                                </tr>
                                <tr>
                                    <td width="50%" style="text-align: left;"><label><b>Date<b></label></td>
                                    <td width="50%" style="text-align: right;"><?php if($status == 1){if($accessed_by == 'user'){
									echo date("M d, Y", strtotime($row['date']));}
                                        } else{
                                        echo "";
                                        }
                                        ?></td>
                                </tr>
                                <tr>
                                    <td width="50%" style="text-align: left;"><label><b>Time-in<b></label></td>
                                    <td width="50%" style="text-align: right;"><?php if($status == 1){if($accessed_by == 'user'){
									echo date("h:i A", strtotime($row['time_in']));}
                                        } else{
                                        echo "";
                                        }
                                        ?></td>
                                </tr>
								<tr>
									<td width="50%" style="text-align: left;"><label><b>Logged in Image</b></label></td>
									<td width="50%" style="text-align: right;">
										<?php
										if ($status == 1 && $accessed_by == 'user') {
											echo '<img src="data:image/png;base64,' . base64_encode($row['logged_in_pic']) . '" alt="Logged in Image">';
										} else {
											echo "";
										}
										?>
									</td>
								</tr>
                            </tbody>
                    </div>
                    <?php endwhile; ?>
                    </table>
                    <form action="" method="POST" style="margin-left:auto; margin-right: auto; width: 70%">
                        <h5> ESP8266 Door Lock Control</h5>
                        <select class="form-select" name="door_status" style="text-align: center;">
                            <option value="1" <?php if ($door_status == 1) echo 'selected'; ?>>Unlock</option>
                            <option value="0" <?php if ($door_status == 0) echo 'selected'; ?>>Lock</option>
                        </select>
                        <br>
                        <table class="table" style="table-layout: fixed; width: 100%">
                            <tbody>
                                <?php 
                                    $result = $conn2->query("SELECT status,accessed_by FROM room_1") or die($db->error);
                                    ?>
                                <?php
                                    while ($row = $result->fetch_assoc()): 
                                    $status = $row['status'];
									$accessed_by = $row['accessed_by'];
                                    ?>
                                <tr>
                                    <td width="50%"><label><b>Door Status<b></label></td>
                                    <td width="50%" style="text-align: center"><?php if ($status == 0){
                                        echo 'Door locked'; 
                                        } else {
                                        echo 'Door unlocked';
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="50%"><label><b>Room Status<b></label></td>
                                    <td width="50%" style="text-align: center"><?php if ($status == 0){
                                        echo 'Available'; 
                                        } else {
                                        echo 'Occupied';
                                        }
                                        ?>
                                    </td>
                                </tr>
								<tr>
                                    <td width="50%"><label><b>Accessed by<b></label></td>
                                    <td width="50%" style="text-align: center"><?php if ($accessed_by == "admin"){
                                        echo 'admin'; 
                                        } else {
                                        echo 'user';
                                        }
                                        ?>
                                    </td>
                                </tr>
                            </tbody>
            </div>
            <?php endwhile;     
    // Close the database connection
    mysqli_close($conn2);?>
            </table>
            <input type="submit" value="Update" class="btn btn-dark btn-block mb-4"></button>
            </form>  
        </div>
        </main>
        </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="../assets/demo/chart-area-demo.js"></script>
        <script src="../assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
    </body>
</html>