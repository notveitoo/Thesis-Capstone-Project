<?php
// Start session
session_start();

// Set timezone to Asia/Manila
date_default_timezone_set('Asia/Manila');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form values
    $room_number = $_POST['room_number'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $date_start = $_POST['date_start'];
    $date_end = $_POST['date_end'];
    $month_start = $_POST['month_start'];
    $month_end = $_POST['month_end'];
    $year_start = $_POST['year_start'];
    $year_end = $_POST['year_end'];
    $week_start = $_POST['week_start'];
    $week_end = $_POST['week_end'];
	
	    // Convert the numeric string to an integer
$room_number = (int)$room_number;

    // Database connection settings
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "iraucv_db";

    // Create database connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query the database based on the selected value
    $query = "SELECT * FROM room_1_attendance WHERE ";



// Add conditions based on the provided input fields
if (!empty($room_number)) {
    $query .= "room_number = $room_number AND ";
}
	
    if (!empty($employee_number)) {
        $query .= "employee_number = '$employee_number' AND ";
    }
    if (!empty($room_number)) {
        $query .= "TIME(time_in) BETWEEN '$start_time' AND '$end_time' AND ";
    }

    if (!empty($week_start) && !empty($week_end)) {
        $query .= "WEEK(date) BETWEEN '$week_start' AND '$week_end' AND ";
    }

    if (!empty($date_start) && !empty($date_end)) {
        $query .= "DATE(date) BETWEEN '$date_start' AND '$date_end' AND ";
    }

    if (!empty($month_start) && !empty($month_end)) {
        $query .= "MONTH(date) BETWEEN '$month_start' AND '$month_end' AND ";
    }

    if (!empty($year_start) && !empty($year_end)) {
        $query .= "YEAR(date) BETWEEN '$year_start' AND '$year_end' AND ";
    }

    // Remove the trailing "AND" from the query
    $query = rtrim($query, " AND ");

    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // Generate CSV file with timestamp in the filename
        $timestamp = date('Ymd_His');
        $filename = 'attendance_report_' . $timestamp . '.csv';

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '";');

        $output = fopen('php://output', 'w');
        fputcsv($output, array('room_number', 'employee_number', 'employee_name', 'date', 'time_in', 'time_out', 'logged_out_by'));

        while ($row = $result->fetch_assoc()) {

            // Write the row data to the CSV file
            fputcsv($output, array(
                $row['room_number'],
                $row['employee_number'],
                $row['employee_name'],
                $row['date'],
                $row['time_in'],
                $row['time_out'],
                $row['logged_out_by']
            ));
        }

        fclose($output);
        exit;
   } else {
    $message = "No data were generated.";
	echo $message;

	}
	// Close database connection
    $conn->close();
	// Redirect to reports.php with the message as a query parameter
    header('Location: reports.php');

}
?>


