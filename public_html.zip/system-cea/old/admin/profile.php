<?php
    @include '../config.php';
    session_start();
    
    if(!isset($_SESSION['admin_name'])){
       header('location:../login_form.php');
    }
    ?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Profile</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="dashboard.php"><img src="../img/cea.png" style="width: 25%; margin-left:30%; display: inline-block; margin-right: auto; margin-bottom: 0px"></a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="profile.php">Settings</a></li>
                        <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <a class="nav-link" href="dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
							<a class="nav-link" href="employee_details.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-info"></i></i></div>
                                Employee Details
                            </a>
                            <a class="nav-link" href="attendance.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></i></div>
                                Attendance
                            </a>
                            <a class="nav-link" href="reports.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Reports
                            </a>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseManageUsers" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Manage Users
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseManageUsers" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="addUser.php">Add User</a>
                                    <a class="nav-link" href="manageUsers.php">Manage</a>
                                </nav>
                            </div>
                        </div>
                    </div>

                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        <?php if (isset($_SESSION['admin_name'])): ?>
                        <?php echo "Administrator ", ucfirst($_SESSION['admin_name']);  ?> <?php endif ?>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Profile</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Administrator</li>
                        </ol>
                        
                        <main id="main" class="main">
            <?php 
               if (isset($_SESSION['message'])): ?>
            <div class="d-flex justify-content-around">
               <div class="alert alert-<?=$_SESSION['msgtype']?> alert-dismissible fade show fade-in">
                  <?php echo $_SESSION['message'];
                     unset($_SESSION['message']);
                     ?>
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
               </div>
            </div>
            <?php endif ?>
            <section class="section profile">
               <div class="row">
                  <div class="col-xl-4">
                     <div class="card">
                        <div class="card-body profile-card d-flex flex-column align-items-center">
                           <img src="../img/cea.png" alt="Profile" class="rounded-circle" style="width:35%;">
                           <br>
                           <?php 
                              $userID = $_SESSION['user_id'];
                              $result = $conn1->query("SELECT * FROM `user_form` WHERE id = $userID") or die($db->error);
                              ?>
                           <?php while ($row = $result->fetch_assoc()): ?>
                           <h4><?php echo $row['name'];?></h4>
                           <p1 style="text-align: center;">Administrator</p1>
                           <p style="text-align: center;">College of Engineering and Architecture</p>
                           <!-- <div class="social-links mt-2">
                              <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
                              <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                              <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                              <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
                              </div> -->
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-8">
                     <div class="card">
                        <div class="card-body pt-3">
                           <!-- Bordered Tabs -->
                           <ul class="nav nav-tabs nav-tabs-bordered">
                              <li class="nav-item">
                                 <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
                              </li>
                              <li class="nav-item">
                                 <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Edit Profile</button>
                              </li>
                              <li class="nav-item">
                                 <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-change-password">Change Password</button>
                              </li>
                           </ul>
                           <div class="tab-content pt-2">
                              <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                 <br>                  
                                 <div class="row">
                                    <div class="col-lg-3 col-md-4 label ">Full Name</div>
                                    <div class="col-lg-9 col-md-8"><?php echo $row['name'];?></div>
                                 </div>
                                 <br>
                                 <div class="row">
                                    <div class="col-lg-3 col-md-4 label">Email</div>
                                    <div class="col-lg-9 col-md-8"><?php echo $row['email'];?></div>
                                 </div>
                                 <br>
                                 <div class="row">
                                    <div class="col-lg-3 col-md-4 label">Role</div>
                                    <div class="col-lg-9 col-md-8"><?php echo $row['user_type'];?></div>
                                 </div>
                              </div>
                              <div class="tab-pane fade profile-edit pt-3" id="profile-edit">
                                 <!-- Profile Edit Form -->
                                 <form method="POST" action="../editProfile.php">
                                    <div class="row mb-3">
                                       <!-- UserID Input Field -->
                                       <div class="col-md-8 col-lg-9">
                                          <input name="userID" type="hidden" class="form-control" id="userID" value="<?php echo $row['id'];?>">
                                       </div>
                                    </div>
                                    <div class="row mb-3">
                                       <label class="col-md-4 col-lg-3 col-form-label">Name</label>
                                       <div class="col-md-8 col-lg-9">
                                          <input name="fullName" type="text" class="form-control" value="<?php echo $row['name'];?>">
                                       </div>
                                    </div>
                                    <div class="row mb-3">
                                       <label class="col-md-4 col-lg-3 col-form-label">Email</label>
                                       <div class="col-md-8 col-lg-9">
                                          <input name="email" type="text" class="form-control" value="<?php echo $row['email'];?>">
                                       </div>
                                    </div>
                                    <div class="text-center">
                                       <button type="submit" name="updateAdminProfile" class="btn btn-secondary">Save Changes</button>
                                    </div>
                                 </form>
                                 <!-- End Profile Edit Form -->
                              </div>
                              <div class="tab-pane fade pt-3" id="profile-change-password">
                                 <!-- Change Password Form -->
                                 <form method="POST" action="../changePassword.php">
                                    <div class="row mb-3">
                                       <!-- UserID Input Field -->
                                       <div class="col-md-8 col-lg-9">
                                          <input name="userID" type="hidden" class="form-control" id="userID" value="<?php echo $row['id'];?>">
                                       </div>
                                    </div>
                                    <?php endwhile?>
                                    <div class="row mb-3">
                                       <label for="currentPassword" class="col-md-4 col-lg-3 col-form-label">Current Password</label>
                                       <div class="col-md-8 col-lg-9">
                                          <input name="currentPassword" type="password" class="form-control" id="currentPassword">
                                       </div>
                                    </div>
                                    <div class="row mb-3">
                                       <label for="newPassword" class="col-md-4 col-lg-3 col-form-label">New Password</label>
                                       <div class="col-md-8 col-lg-9">
                                          <input name="newPassword" type="password" class="form-control" id="newPassword">
                                       </div>
                                    </div>
                                    <div class="row mb-3">
                                       <label for="renewPassword" class="col-md-4 col-lg-3 col-form-label">Re-enter New Password</label>
                                       <div class="col-md-8 col-lg-9">
                                          <input name="confirmPassword" type="password" class="form-control" id="confirmPassword">
                                       </div>
                                    </div>
                                    <div class="text-center">
                                       <button type="submit" class="btn btn-secondary" name="changePassword">Change Password</button>
                                    </div>
                                 </form>
                                 <!-- End Change Password Form -->
                              </div>
                           </div>
                           <!-- End Bordered Tabs -->
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         </main>
                            


	
                        
                    </div>
                </main>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
    </body>
</html>
