<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login_form.php');
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin page</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
	<link rel="stylesheet" href="css/style_nav.css">
</head>
<body>
	<div class="container">
    <nav>
      <ul>
        <li><a href="#" class="logo">
          <img src="./pic/logo.jpg">
          <span class="nav-item">Admin</span>
        </a></li>
        <li><a href="admin_page.php">
          <i class="fas fa-home"></i>
          <span class="nav-item">Dashboard</span>
        </a></li>
        <li><a href="admin_attendance.php">
          <i class="fas fa-chart-bar"></i>
          <span class="nav-item">Attendance</span>
        </a></li>
        <li><a href="admin_report.php">
          <i class="fas fa-database"></i>
          <span class="nav-item">Report</span>
        </a></li>
        <li><a href="register_form.php">
          <i class="fas fa-plus-square"></i>
          <span class="nav-item">Add</span>
        </a></li>
        <li><a href="admin_update_profile.php">
          <i class="fas fa-cog"></i>
          <span class="nav-item">Update</span>
        </a></li>
		<li><a href="delete_profile.php">
          <i class="fas fa-trash-alt"></i>
          <span class="nav-item">Delete</span>
        </a></li>

        <li><a href="logout.php" class="logout">
          <i class="fas fa-sign-out-alt"></i>
          <span class="nav-item">Log out</span>
        </a></li>
      </ul>
    </nav>

	<div class="content">
		<h3>hi, <span>admin</span></h3>
		<h1>welcome <span><?php echo $_SESSION['admin_name'] ?></span></h1>
		<p>this is an admin report page</p>
	</div>
</body>
</html>