<?php
    @include 'config.php';
    
    session_start();
    
    if(!isset($_SESSION['admin_name'])){
       header('location:login_form.php');
    }
    
    if(isset($_POST['submit'])){
       $name = mysqli_real_escape_string($conn, $_POST['name']);
       $email = mysqli_real_escape_string($conn, $_POST['email']);
       $pass = md5($_POST['password']);
       $cpass = md5($_POST['cpassword']);
       $user_type = $_POST['user_type'];
       //added
       $image = $_FILES['image']['name'];
       $image_size = $_FILES['image']['size'];
       $image_tmp_name = $_FILES['image']['tmp_name'];
       $image_folder = 'uploaded_img/'.$image;
    
    
       $select = " SELECT * FROM user_form WHERE email = '$email' && password = '$pass' ";
    
       $result = mysqli_query($conn, $select);
       
       if(mysqli_num_rows($result) > 0){
          $error[] = 'user already exist'; 
       }else{
          if($pass != $cpass){
             $error[] = 'password does not matched!';
          }elseif($image_size > 2000000){
             $error[] = 'image size is too large!';
          }else{
             $insert = mysqli_query($conn, "INSERT INTO `user_form`(name, email, password, image, user_type) VALUES('$name', '$email', '$pass', '$image','$user_type'") or die('query failed');
    
             if($insert){
                move_uploaded_file($image_tmp_name, $image_folder);
                $error[] = 'registered successfully!';
                header('location:login_form.php');
             }else{
                $error[] = 'registeration failed!';
             }
          }
       }
    }
    
    ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>register form</title>
        <!-- custom css file link  -->
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
        <link rel="stylesheet" href="css/login-form.css">
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="#" class="logo">
                    <img src="./photos/cea.png">
                    <span class="nav-item">Admin</span>
                    </a>
                </li>
                <li><a href="admin_page.php">
                    <i class="fas fa-home"></i>
                    <span class="nav-item">Dashboard</span>
                    </a>
                </li>
                <li><a href="admin_attendance.php">
                    <i class="fas fa-chart-bar"></i>
                    <span class="nav-item">Attendance</span>
                    </a>
                </li>
                <li><a href="admin_report.php">
                    <i class="fas fa-database"></i>
                    <span class="nav-item">Report</span>
                    </a>
                </li>
                <li><a href="register_form.php">
                    <i class="fas fa-plus-square"></i>
                    <span class="nav-item">Add</span>
                    </a>
                </li>
                <li><a href="admin_update_profile.php">
                    <i class="fas fa-cog"></i>
                    <span class="nav-item">Update</span>
                    </a>
                </li>
                <li><a href="delete_profile.php">
                    <i class="fas fa-trash-alt"></i>
                    <span class="nav-item">Delete</span>
                    </a>
                </li>
                <li><a href="logout.php" class="logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span class="nav-item">Log out</span>
                    </a>
                </li>
            </ul>
        </nav>
        <h1>welcome <span><?php echo $_SESSION['admin_name'] ?></span></h1>
        <p>this is an register form page</p>
        <div class="form-container">
            <form action="" method="post">
                <h3>register now</h3>
                <?php
                    if(isset($error)){
                       foreach($error as $error){
                          echo '<span class="error-msg">'.$error.'</span>';
                       };
                    };
                    ?>
                <input type="text" name="name" required placeholder="enter your name">
                <input type="email" name="email" required placeholder="enter your email">
                <input type="password" name="password" required placeholder="enter your password">
                <input type="password" name="cpassword" required placeholder="confirm your password">
                <input type="file" name="image" class="box" accept="image/jpg, image/jpeg, image/png">
                <select name="user_type">
                    <option value="user">user</option>
                    <option value="admin">admin</option>
                </select>
                <input type="submit" name="submit" value="Add user" class="form-btn">
                <p><a href="admin_page.php">go back</a></p>
            </form>
        </div>
    </body>
</html>