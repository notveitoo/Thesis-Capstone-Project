<?php
@include 'config.php';

session_start();

    if(isset($_GET['deleteUser'])){
    $userID = $_GET['deleteUser'];
    
    $conn1->query("DELETE FROM user_form WHERE id=$userID")or die($db->error);
        
    $_SESSION['messages'] = "User deleted successfully.";
    $_SESSION['msgtypes'] = "danger";
    header("location: admin/manageUsers.php");
    }

?>