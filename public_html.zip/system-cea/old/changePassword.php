<?php
@include 'config.php';

session_start();

if (isset($_POST['changePassword'])) {
    $userID= mysqli_real_escape_string($conn1, $_POST['userID']);
    $currentPassword= mysqli_real_escape_string($conn1, $_POST['currentPassword']);
    $newPassword= mysqli_real_escape_string($conn1, $_POST['newPassword']);
    $confirmPassword= mysqli_real_escape_string($conn1, $_POST['confirmPassword']);
    $encrypted_old_password = md5($currentPassword);
    $encrypted_new_password = md5($newPassword);
    
        $query = "SELECT * FROM user_form WHERE `id` = '$userID'";
        $result = mysqli_query($conn1, $query);
        if(mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            $userID = $row['id'];
            $userType = $row['user_type'];
            $password = $row['password'];
        }
            
            
            if($encrypted_old_password == $password && $newPassword == $confirmPassword){
                $conn1->query("UPDATE `user_form` SET `password`='$encrypted_new_password' WHERE `id`='$userID'");
                $_SESSION['message'] = "New Password has been set";
                $_SESSION['msgtype'] = "success";
                if($userType == "user"){

                    header("location: user/profile.php");
                 }else{
                     header("location: admin/profile.php");
                }
            }else{
                $_SESSION['message'] = "Current or new password not matched";
                $_SESSION['msgtype'] = "danger";
                if($userType == "user"){
                    header("location: user/profile.php");
                 }else{
                     header("location: admin/profile.php");
                }
            }
        
    }

?>