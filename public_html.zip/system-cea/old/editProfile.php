<?php
@include 'config.php';

session_start();

if (isset($_POST['updateAdminProfile'])) {
    $userID= mysqli_real_escape_string($conn1, $_POST['userID']);
    $fullName= mysqli_real_escape_string($conn1, $_POST['fullName']);
    $email= mysqli_real_escape_string($conn1, $_POST['email']);

        $_SESSION['message'] = "Changes has been saved";
        $_SESSION['msgtype'] = "success";

        $conn1->query("UPDATE `user_form` SET `name`='$fullName', `email`='$email' WHERE `id`='$userID'");
        header("location: admin/profile.php");
        if($_SESSION['user_type'] == "admin"){

            header("location: admin/profile.php");
         }else{
            header("location: user/profile.php");
        }
       
}

?>