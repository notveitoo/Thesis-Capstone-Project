<?php
@include 'config.php';

session_start();

if (!isset($_SESSION['admin_name'])) {
    header('location:../login_form.php');
}

if (isset($_GET['editUser'])) {
    $userId = $_GET['editUser'];

    if (isset($_POST['updateUser'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $userType = $_POST['user_type'];

        // Perform the update query
        $updateQuery = "UPDATE `user_form` SET name = '$name', email = '$email', user_type = '$userType' WHERE id = '$userId'";
        if ($conn1->query($updateQuery) === TRUE) {
            $_SESSION['messages'] = 'User updated successfully.';
            $_SESSION['msgtypes'] = 'success';
            header('location: manageUsers.php');
            exit();
        } else {
            $_SESSION['messages'] = 'Error updating user: ' . $conn1->error;
            $_SESSION['msgtypes'] = 'danger';
        }
    }

    // Fetch the user data based on the user ID
    $query = "SELECT * FROM `user_form` WHERE id = '$userId'";
    $result = $conn1->query($query);

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
    } else {
        $_SESSION['messages'] = 'User not found.';
        $_SESSION['msgtypes'] = 'danger';
        header('location: manageUsers.php');
        exit();
    }
} else {
    $_SESSION['messages'] = 'Invalid request.';
    $_SESSION['msgtypes'] = 'danger';
    header('location: manageUsers.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Edit User</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <link rel="icon" href="../img/cea.png">
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Edit User</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Administrator</li>
                    </ol>
                    <?php if (isset($_SESSION['messages'])): ?>
                        <div class="d-flex justify-content-around">
                            <div class="alert alert-<?=$_SESSION['msgtypes']?> alert-dismissible fade show fade-in">
                                <?php echo $_SESSION['messages'];
                                unset($_SESSION['messages']);
                                ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    <?php endif ?>
                    <div class="card mb-4">
                        <div class="card-header">                            
						<i class="fas fa-user-edit me-1"></i> Edit User
                        </div>
                        <div class="card-body">
                            <form action="" method="POST">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $user['name']; ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="user_type" class="form-label">User Type</label>
                                    <select class="form-select" id="user_type" name="user_type" required>
                                        <option value="admin" <?php if ($user['user_type'] == 'admin') echo 'selected'; ?>>Admin</option>
                                        <option value="user" <?php if ($user['user_type'] == 'user') echo 'selected'; ?>>User</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <button type="submit" name="updateUser" class="btn btn-primary">Update</button>
                                    <a href="admin/manageUsers.php" class="btn btn-secondary">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/script.min.js"></script>
        <script src="../js/scripts.js"></script>
    </body>
</html>
