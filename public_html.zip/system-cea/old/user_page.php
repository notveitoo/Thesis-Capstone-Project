<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>user page</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
	<link rel="stylesheet" href="css/style_nav.css">
</head>
<body>
<nav class="navbar">
		<div class="navdiv">
			<div class="logo"><a href="user_page.php">CPEnois</a> </div>
			<ul>
				<li><a href="user_page.php">Home</a></li>
				<li><a href="user_attendance.php">Attendance</a></li>
				<li><a href="user_report.php">Report</a></li>
            <li><a href="user_update_profile.php">Profile</a></li>
				<li><a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a></li>
			</ul>
		</div>
	</nav>
   <div class="content">
      <h3>hi, <span>user</span></h3>
      <h1>welcome <span><?php echo $_SESSION['user_name'] ?></span></h1>
      <p>this is an user page</p>
   </div>
</body>
</html>