<?php
@include 'config.php';

session_start();

    if(isset($_GET['activateUser'])){
    $userID = $_GET['activateUser'];
    
    $conn1->query("UPDATE `user_form` SET `status`='Active' WHERE `id`='$userID'");
        
    $_SESSION['messages'] = "User activated";
    $_SESSION['msgtypes'] = "success";
    header("location: admin/manageUsers.php");
    }

    if(isset($_GET['deactivateUser'])){
    $userID = $_GET['deactivateUser'];
    
    $conn1->query("UPDATE `user_form` SET `status`='Inactive' WHERE `id`='$userID'");
        
    $_SESSION['messages'] = "User deactivated";
    $_SESSION['msgtypes'] = "danger";
    header("location: admin/manageUsers.php");
    }

?>