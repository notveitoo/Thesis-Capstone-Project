<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin page</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
	<link rel="stylesheet" href="css/style_nav.css">
</head>
<body>
	<div class="container">
    <nav>
      <ul>
        <li><a href="#" class="logo">
          <img src="photos/cea.png">
          <span class="nav-item">Admin</span>
        </a></li>
        <li><a href="admin_page.php">
          <i class="fas fa-home"></i>
          <span class="nav-item">Dashboard</span>
        </a></li>
        <li><a href="admin_attendance.php">
          <i class="fas fa-chart-bar"></i>
          <span class="nav-item">Attendance</span>
        </a></li>
        <li><a href="admin_report.php">
          <i class="fas fa-database"></i>
          <span class="nav-item">Report</span>
        </a></li>
        <li><a href="register_form.php">
          <i class="fas fa-plus-square"></i>
          <span class="nav-item">Add</span>
        </a></li>
        <li><a href="admin_update_profile.php">
          <i class="fas fa-cog"></i>
          <span class="nav-item">Update</span>
        </a></li>
		<li><a href="delete_profile.php">
          <i class="fas fa-trash-alt"></i>
          <span class="nav-item">Delete</span>
        </a></li>

        <li><a href="logout.php" class="logout">
          <i class="fas fa-sign-out-alt"></i>
          <span class="nav-item">Log out</span>
        </a></li>
      </ul>
    </nav>
	<section class="main">
      <div class="main-top">
        <h1>DASHBOARD</h1>
      </div>
	  <div class="head">
        <h2>ROOMS</h2>
      </div>
      <div class="users">
        <div class="card">
          <h4>ROOM #1</h4>
          <button>AVAILABLE</button>
		  <button2>OCCUPIED</button2>
        </div>
        <div class="card">
          <h4>ROOM #2</h4>
          <button>AVAILABLE</button>
		  <button2>OCCUPIED</button2>
        </div>
        <div class="card">
          <h4>ROOM #3</h4>
          <button>AVAILABLE</button>
		  <button2>OCCUPIED</button2>
        </div>
        <div class="card">
          <h4>ROOM #4</h4>
          <button>AVAILABLE</button>
		  <button2>OCCUPIED</button2>
        </div>
      </div>

      <section class="attendance">
        <div class="attendance-list">
          <h1>ROOM USERS</h1>
          <table class="table">
            <thead>
              <tr>
                <th>Room no.</th>
                <th>Name</th>
                <th>Depart</th>
                <th>Date</th>
                <th>Log-in Time</th>
                <th>Logout Time</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>01</td>
                <td>---</td>
                <td>---</td>
                <td>---</td>
                <td>---</td>
                <td>---</td>
                <td><button>View</button></td>
              </tr>
              <tr class="active">
                <td>02</td>
                 <td>---</td>
                <td>---</td>
                <td>---</td>
                <td>---</td>
                <td>---</td>
                <td><button>View</button></td>
              </tr>
              <tr>
                <td>03</td>
                 <td>---</td>
                <td>---</td>
                <td>---</td>
                <td>---</td>
                <td>---</td>
                <td><button>View</button></td>
              </tr>
              <tr>
                <td>04</td>
                 <td>---</td>
                <td>---</td>
                <td>---</td>
                <td>---</td>
                <td>---</td>
                <td><button>View</button></td>
              </tr>
              <!-- <tr >
                <td>05</td>
                <td>Salina</td>
                <td>Coding</td>
                <td>03-24-22</td>
                <td>9:00AM</td>
                <td>4:00PM</td>
                <td><button>View</button></td>
              </tr>
              <tr >
                <td>06</td>
                <td>Tara Smith</td>
                <td>Testing</td>
                <td>03-24-22</td>
                <td>9:00AM</td>
                <td>4:00PM</td>
                <td><button>View</button></td>
              </tr> -->
            </tbody>
          </table>
        </div>
      </section>
    </section>
  </div>
</body>
</html>