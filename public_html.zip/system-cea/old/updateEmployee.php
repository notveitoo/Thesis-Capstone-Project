<?php
@include 'config.php';

session_start();

if (isset($_POST['updateEmployee'])) {
    $employeeNumber = $_POST['employee_number'];
    $employeeName = $_POST['employee_name'];
    $accountStatus = $_POST['account_status'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $birthdate = $_POST['birthdate'];
    $address1 = $_POST['address1'];
    $address2 = $_POST['address2'];
    $address3 = $_POST['address3'];
    //$zipcode = $row['zipcode'];
    
    $_SESSION['message'] = "Profile updated";
    $_SESSION['msgtype'] = "success";

    $conn2->query("UPDATE `employee_details` SET `employee_name`='$employeeName', `account_status`='$accountStatus', `gender`='$gender',
    `email` = '$email', `birthdate` = '$birthdate', `address1` = '$address1', `address2` = '$address2', `address3` = '$address3' 
    WHERE `employee_number` = '$employeeNumber'");
    header("location: admin/employee_details.php?search=$employeeNumber");

}

?>