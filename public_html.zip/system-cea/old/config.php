<?php

$conn1 = mysqli_connect('localhost','root','','user_form');
$conn2 = mysqli_connect('localhost','root','','iraucv_db');


?>