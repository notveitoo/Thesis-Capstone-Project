<?php
// Replace with your database details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "iraucv_db";

// Create a new connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!empty($_POST)) {
    $id = $_POST["ID"];
    $sql = "SELECT status FROM room_1 WHERE ID = 1";
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo $row['status'];
    } else {
        echo "No data found.";
    }
}

$conn->close();
?>
