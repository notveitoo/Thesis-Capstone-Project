<?php
// MySQL database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "iraucv_db";

// Connect to MySQL database
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the door status needs to be updated
if (isset($_POST['door_status'])) {
    $door_status = $_POST['door_status'];

    // Update the door status in the database
    $sql = "UPDATE room_1 SET status='$door_status' WHERE id=1";
    if (mysqli_query($conn, $sql)) {
        echo "Door lock status updated successfully.";
    } else {
        echo "Error updating Door lock status: " . mysqli_error($conn);
    }
}

// Retrieve the current door status from the database
$sql = "SELECT status FROM room_1 WHERE id=1";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$door_status = $row['status'];

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>ESP8266 Door Lock Control</title>
</head>
<body>
    <h1>ESP8266 Door Lock Control</h1>
    <form method="post" action="">
        <label>
            Door lock Status:
            <select name="door_status">
                <option value="1" <?php if ($door_status == 1) echo 'selected'; ?>>Unlock</option>
                <option value="0" <?php if ($door_status == 0) echo 'selected'; ?>>Lock</option>
            </select>
        </label>
        <button type="submit">Update</button>
    </form>
    
    <h1>Current Door Lock Status</h1>
    <?php
    // Create a new connection to the database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL query to select the door status and accessed_by column
    $sql = "SELECT status, accessed_by FROM room_1 WHERE id = 1";
    $result = $conn->query($sql);

    // Check if any rows were returned
    if ($result->num_rows > 0) {
        // Fetch the row and store the values in variables
        $row = $result->fetch_assoc();
        $door_status = $row['status'];
        $accessed_by = $row['accessed_by'];

        // Output the door status
        echo "Door Lock Status: " . $door_status;

        if ($door_status == 0) {
            if ($accessed_by == "user") {
                // Update accessed_by column with 'admin'
                $updateSql = "UPDATE room_1 SET accessed_by = 'admi' WHERE id = 1";
                if ($conn->query($updateSql) === TRUE) {
                    echo " Accessed by column updated successfully.";
                    date_default_timezone_set("Asia/Manila");
                    $current_time = date("Y-m-d H:i:s");
                    // Update logged_out_by column with timestamp
                    $updateSql = "UPDATE room_1_attendance SET logged_out_by = 'admin', time_out ='$current_time'  ORDER BY id DESC LIMIT 1";
                    if ($conn->query($updateSql) === TRUE) {
                        echo " logged out by column updated successfully.";
                    } else {
                        echo "Error updating logged_out_by column: " . $conn->error;
                    }
                } else {
                    echo "Error updating accessed_by column: " . $conn->error;
                }
            } elseif ($accessed_by == "admi") {
                // Update accessed_by column with 'admin'
                $updateSql = "UPDATE room_1 SET accessed_by = 'admin' WHERE id = 1";
                if ($conn->query($updateSql) === TRUE) {
                    echo " Accessed by column updated successfully.";
                } else {
                    echo " Error updating accessed_by column: " . $conn->error;
                }
            } else {
                echo " No Door Lock status available. ";
            }
        } elseif ($door_status == 1) {
            // Update accessed_by column with 'admin'
            $updateSql = "UPDATE room_1 SET accessed_by = 'admin' WHERE id = 1";
            if ($conn->query($updateSql) === TRUE) {
                echo " Accessed by column updated successfully.";
            } else {
                echo "Error updating accessed_by column: " . $conn->error;
            }
        } else {
            echo " No data found.";
        }
    } else {
        echo "No Door Lock status available.";
    }

    // Close the database connection
    $conn->close();
    ?>
</body>
</html>
