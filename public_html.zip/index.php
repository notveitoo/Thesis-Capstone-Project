<?php
header("Location: system-cea/login_form.php");
exit;
?>
